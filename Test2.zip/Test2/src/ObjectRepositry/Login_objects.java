package ObjectRepositry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login_objects {

	WebDriver driver;
	public Login_objects (WebDriver Driver2)
	{
		this.driver=Driver2;
	}
	public By login_button_start  = By.xpath("//div[@class='HPHeaderLogin']/a[1]/img[1]"); 
	//define the locator for the login button in the home page make it public to use it in the wait function 
	By login_username = By.xpath("//input[@id='ctl00_MainContent_LoginControl1_TextBoxEmail']"); //define the locator for the username field
	By login_password = By.xpath("//input[@id='ctl00_MainContent_LoginControl1_TextBoxPassword']");//define the locator for the password field 
	By login_go = By.xpath("//input[@id='ctl00_MainContent_LoginControl1_ButtonLogin']"); //define locator for login button on the login form
	//Projects Tile
	By projects_button = By.xpath("//div[@id='TitleProjects']"); //define the locator of the projects tile
	By projects_addNew_button = By.xpath("//div[@id='Div2']");//define the locator of the projects add new icon
	By projects_content = By.xpath("//input[@id='NewProjNameInput']");//define the locator of the projects content input field
	By projects_add_go = By.xpath("//input[@id='NewProjNameButton']"); //define the locator of the add project button
	//To Do 
	By todo_seeAll = By.xpath("//a[@id='DoneItemsShowLink']"); //define locator of the "see all"icon in the project todo field
	By todo_content = By.xpath("//textarea[@id='NewItemContentInput']"); //define locator of todo input field
	By todo_addNew_button = By.xpath("//input[@id='NewItemAddButton']"); //define locator of add todo button
	
	//in the below lines I'm defining new method for each and every locator to use it in the test case
	public WebElement login_button_start1() {
		return driver.findElement(login_button_start);
	}
	public WebElement login_username() {
		return driver.findElement(login_username);
	}
	public WebElement login_password() {
		return driver.findElement(login_password);
	}
	public WebElement login_go() {
		return driver.findElement(login_go);
	}
	//projects
	public WebElement projects_button() {
		return driver.findElement(projects_button);
	}
	public WebElement projects_addNew_button() {
		return driver.findElement(projects_addNew_button); 
	}
	public WebElement projects_content() {
		return driver.findElement(projects_content);
	}
	public WebElement projects_add_go() {
		return driver.findElement(projects_add_go);
	}
	//ToDo
	public WebElement todo_seeAll() { 
		return driver.findElement(todo_seeAll);
	}
	public WebElement todo_content() {
		return driver.findElement(todo_content);
	}
	public WebElement todo_addNew_button() {
		return driver.findElement(todo_addNew_button);
	}
}
