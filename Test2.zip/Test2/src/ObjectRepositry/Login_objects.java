package ObjectRepositry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login_objects {

	WebDriver driver;
	public Login_objects (WebDriver Driver2)
	{
		this.driver=Driver2;
	}
	public By login_button_start  = By.xpath("//div[@class='HPHeaderLogin']/a[1]/img[1]");
	By login_username = By.xpath("//input[@id='ctl00_MainContent_LoginControl1_TextBoxEmail']"); 
	By login_password = By.xpath("//input[@id='ctl00_MainContent_LoginControl1_TextBoxPassword']");
	By login_go = By.xpath("//input[@id='ctl00_MainContent_LoginControl1_ButtonLogin']");
	//Projects Tile
	By projects_button = By.xpath("//div[@id='TitleProjects']"); 
	By projects_addNew_button = By.xpath("//div[@id='Div2']");
	By projects_content = By.xpath("//input[@id='NewProjNameInput']");
	By projects_add_go = By.xpath("//input[@id='NewProjNameButton']");
	//To Do 
	By todo_seeAll = By.xpath("//a[@id='DoneItemsShowLink']");
	By todo_content = By.xpath("//textarea[@id='NewItemContentInput']");
	By todo_addNew_button = By.xpath("//input[@id='NewItemAddButton']");
	
	public WebElement login_button_start1() {
		return driver.findElement(login_button_start);
	}
	public WebElement login_username() {
		return driver.findElement(login_username);
	}
	public WebElement login_password() {
		return driver.findElement(login_password);
	}
	public WebElement login_go() {
		return driver.findElement(login_go);
	}
	//projects
	public WebElement projects_button() {
		return driver.findElement(projects_button);
	}
	public WebElement projects_addNew_button() {
		return driver.findElement(projects_addNew_button); 
	}
	public WebElement projects_content() {
		return driver.findElement(projects_content);
	}
	public WebElement projects_add_go() {
		return driver.findElement(projects_add_go);
	}
	//ToDo
	public WebElement todo_seeAll() { 
		return driver.findElement(todo_seeAll);
	}
	public WebElement todo_content() {
		return driver.findElement(todo_content);
	}
	public WebElement todo_addNew_button() {
		return driver.findElement(todo_addNew_button);
	}
}
