package TestCase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import ObjectRepositry.Login_objects;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class LoginPage {
	
	@Test
	public void Login() throws ATUTestRecorderException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Automation\\chromedriver_win32\\chromedriver.exe");	
		ATUTestRecorder recorder = new ATUTestRecorder("c:\\Automation","recording",false); // to record a video without audio 
		recorder.start(); //start recording
		WebDriver driver = new ChromeDriver(); 
		driver.get("http:\\todo.ly");
		driver.manage().window().maximize(); 
		driver.get("https://todo.ly");
		Login_objects lo=new Login_objects (driver);
		//Wait.until(ExpectedConditions.visibilityOfElementLocated(lo.login_button_start));
		lo.login_button_start1().click();
		lo.login_username().sendKeys("iman.m.m.ali.a@gmail.com");
		lo.login_password().sendKeys("iman");
		lo.login_go().click();
		
		//Create a new project 
		lo.projects_button().click();
		lo.projects_addNew_button().click();
		lo.projects_content().sendKeys("New Project");
		lo.projects_add_go().click();
		
		//Create Todo inside the project 
		lo.todo_seeAll().click();//this is an extra step to make sure we are inside the project 
		lo.todo_content().sendKeys("New ToDo");
		lo.todo_addNew_button().click();
		
		//stop recording
		recorder.stop();
}
}