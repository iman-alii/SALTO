package TestCase;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import ObjectRepositry.Login_objects;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class LoginPage {
	WebDriver driver;
	WebDriverWait wait;
	Robot Robot;

	@BeforeMethod
	public void beforeMethod() throws AWTException, ATUTestRecorderException { // I set here all the prior steps to
																				// testing
		System.setProperty("webdriver.chrome.driver", "C:\\Automation\\chromedriver_win32\\chromedriver.exe"); 
		// set browser property 
		driver = new ChromeDriver(); // new instance of chrome driver
		wait = new WebDriverWait(driver, 20); // define a wait of max 20 msec
		Robot = new Robot(); // define robot (used to capture a screenshot
	}

	private void CaptureScreen() throws IOException, AWTException { // to capture screenshot

		Rectangle area = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
		BufferedImage bufferedImage = Robot.createScreenCapture(area);
		File file = new File("Todoly.png"); // take screenshot of name Todoly
		ImageIO.write(bufferedImage, "png", file);
		// screenshot will be saved inside the project workspace
	}

	@Test
	public void Login() throws ATUTestRecorderException { // this test case - exception is for the record

		ATUTestRecorder recorder = new ATUTestRecorder("c:\\Automation", "recording", false); // to record a video
																								// without audio
		recorder.start(); // start recording
		WebDriver driver = new ChromeDriver(); // new driver instance
		driver.manage().window().maximize(); // maximize the page
		driver.get("https://todo.ly"); // go to website todo.ly
		Login_objects lo = new Login_objects(driver); // this is to call objects from the page object file
		wait.until(ExpectedConditions.visibilityOfElementLocated(lo.login_button_start)); // wait until the login button
																							// is visible and clickable
		lo.login_button_start1().click(); // click on login from home page
		lo.login_username().sendKeys("iman.m.m.ali.a@gmail.com"); // enter e-mail address as username
		lo.login_password().sendKeys("iman");// enter password
		lo.login_go().click(); // click on login

		// Create a new project
		lo.projects_button().click(); // click on projects tile
		lo.projects_addNew_button().click(); // click on add a new project icon
		lo.projects_content().sendKeys("New Project"); // enter New Project in the content field
		lo.projects_add_go().click(); // click on add

		// Create Todo inside the project
		lo.todo_seeAll().click();// this is an extra step to make sure we are inside the project
		lo.todo_content().sendKeys("New ToDo"); // enter a New ToDo in the todo input field
		lo.todo_addNew_button().click(); // click on add

		// stop recording
		recorder.stop();
	}

	@AfterMethod
	public void AfterMethod() throws IOException, AWTException, InterruptedException {
		CaptureScreen(); // capture screenshot for the final page
		driver.close(); // close the used browser
	}
}
