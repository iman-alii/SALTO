

import org.testng.annotations.Test;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;



public class Todo_Login {
	WebDriver driver;
	WebDriverWait wait;
	Robot Robot;

	@BeforeMethod
	public void beforeMethod() throws AWTException, ATUTestRecorderException {
		System.setProperty("webdriver.chrome.driver", "C:\\Automation\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 20);
		Robot = new Robot(); 
		driver.manage().window().maximize();
	}
		private void CaptureScreen() throws IOException, AWTException { //to capture screenshot 

			    Rectangle area = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
			    BufferedImage bufferedImage = Robot.createScreenCapture(area);
			    File file = new File("Todoly.png"); //take screenshot of name Todoly
			    ImageIO.write(bufferedImage, "png", file);
		
	}
	@Test
	public void TestCase() throws AWTException, ATUTestRecorderException {
		ATUTestRecorder recorder = new ATUTestRecorder("c:\\Automation","recording",false); // to record a video without audio 
		recorder.start(); //start recording
		driver.get("http:\\todo.ly");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='HPHeaderLogin']/a[1]/img[1]"))); //Visibility of the login button
		driver.findElement(By.xpath("//div[@class='HPHeaderLogin']/a[1]/img[1]")).click(); // click on login icon
		driver.findElement(By.xpath("//input[@id='ctl00_MainContent_LoginControl1_TextBoxEmail']")).sendKeys("iman.m.m.ali.a@gmail.com"); //enter username
		driver.findElement(By.xpath("//input[@id='ctl00_MainContent_LoginControl1_TextBoxPassword']")).sendKeys("iman");//enter password
	
		Robot.keyPress(KeyEvent.VK_ENTER);//press enter to login
		Robot.keyRelease(KeyEvent.VK_ENTER);
	
		//now you are logged in next to create a new project 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='TitleProjects']"))); //wait for the projects icon to show
		driver.findElement(By.xpath("//div[@id='Div2']")).click(); // click to add a new project 		
		driver.findElement(By.xpath("//input[@id='NewProjNameInput']")).sendKeys("New Project"); //New project's name
		driver.findElement(By.xpath("//input[@id='NewProjNameButton']")).click(); // click to add a new project 	
	
		
		//Now the project is created successfully next to add a todo
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='DoneItemsShowLink']")));//wait for the ToDo field to show
		driver.findElement(By.xpath("//a[@id='DoneItemsShowLink']")).click(); // extra step to make sure I'm in the correct field 
		driver.findElement(By.id("NewItemContentInput")).sendKeys("New Todo"); //New project's ToDo
		Robot.keyPress(KeyEvent.VK_ENTER); //press enter to create the Todo
		Robot.keyRelease(KeyEvent.VK_ENTER);
		recorder.stop(); //stop recording
		
	}
	
	@AfterMethod 
	public void AfterMethod () throws IOException, AWTException, InterruptedException
	{
		CaptureScreen(); // capture screenshot for the final page
		driver.close(); //close the used browser

	
	}

}